# weather-pytelegrambot
config.py - Telegram your token

![preview](preview.gif)